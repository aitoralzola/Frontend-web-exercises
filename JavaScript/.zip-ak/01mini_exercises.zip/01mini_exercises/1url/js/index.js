function showURL()
{
    var str = window.location.href;
    alert(str);
}
