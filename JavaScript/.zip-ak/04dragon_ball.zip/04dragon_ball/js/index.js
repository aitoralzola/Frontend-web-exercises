function mostrarTodo(){
    console.log("Mostrando todo")
	var db = document.getElementById("db");
	var dbz = document.getElementById("dbz");
	var dbgt = document.getElementById("dbgt");
	db.style.display = "block";	
	dbz.style.display = "block";	
	dbgt.style.display = "block";	
}
function mostrarDb(){
    console.log("Mostrando db")
	var db = document.getElementById("db");
	var dbz = document.getElementById("dbz");
	var dbgt = document.getElementById("dbgt");	
	db.style.display = "block";	
	dbz.style.display = "none";	
	dbgt.style.display = "none";	
}
function mostrarDbz(){
    console.log("Mostrando dbz")
	var db = document.getElementById("db");
	var dbz = document.getElementById("dbz");
	var dbgt = document.getElementById("dbgt");	
	db.style.display = "none";	
	dbz.style.display = "block";	
	dbgt.style.display = "none";	
}
function mostrarDbgt(){
    console.log("Mostrando dbgt")
	var db = document.getElementById("db");
	var dbz = document.getElementById("dbz");
	var dbgt = document.getElementById("dbgt");	
	db.style.display = "none";	
	dbz.style.display = "none";	
	dbgt.style.display = "block";	
}